title: docker迁移镜像
date: '2019-09-10 17:21:54'
updated: '2019-09-10 17:21:54'
tags: [lunix, docker]
permalink: /articles/2019/09/10/1568107314850.html
---
![](https://img.hacpai.com/bing/20190322.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# docker迁移镜像
## 手动
### 将镜像保存为压缩包文件

```
[root@CentOS-7 ~]# docker images nginx
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
docker.io/nginx     latest              5766334bdaa0        2 weeks ago         182.5 MB
[root@CentOS-7 ~]# 
[root@CentOS-7 ~]# docker save  nginx | gzip > nginx-latest.tar.gz
[root@CentOS-7 ~]# 
[root@CentOS-7 ~]# ls -lh nginx-latest.tar.gz 
-rw-r--r-- 1 root root 69M Apr 24 17:28 nginx-latest.tar.gz
[root@CentOS-7 ~]#
```
### 加载镜像

```
# docker images nginx
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
# 
# docker load -i nginx-latest.tar.gz 
5d6cbe0dbcf9: Loading layer [==================================================>] 129.2 MB/129.2 MB
aca7b1f22e02: Loading layer [==================================================>] 9.216 kB/9.216 kB
31fc28b38091: Loading layer [==================================================>] 61.24 MB/61.24 MB
97b903fe0f6f: Loading layer [==================================================>] 3.584 kB/3.584 kB
Loaded image: docker.io/nginx:latest>                                           ]    512 B/3.584 kB
# 
# docker images nginx
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
docker.io/nginx     latest              5766334bdaa0        2 weeks ago         182.5 MB
# 
```
## 快捷命令
将镜像从一个主机迁移到另一个主机：

```
docker save | bzip2 | ssh @ "cat | docker load"
```

```
[root@CentOS-7 ~]# docker images
REPOSITORY              TAG                 IMAGE ID            CREATED             SIZE
docker.io/hello-world   latest              48b5124b2768        3 months ago        1.84 kB
[root@CentOS-7 ~]# 
[root@CentOS-7 ~]# docker save hello-world | bzip2 | ssh root@10.140.1.120 "cat | docker load"
root@10.140.1.120's password: 
Loaded image: docker.io/hello-world:latest
[root@CentOS-7 ~]# 
```
