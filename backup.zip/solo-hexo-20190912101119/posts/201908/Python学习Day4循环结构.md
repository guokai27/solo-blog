title: Python学习Day4-循环结构
date: '2019-08-02 23:19:35'
updated: '2019-08-02 23:19:35'
tags: [python]
permalink: /articles/2019/08/02/1564759175820.html
---
![](https://img.hacpai.com/bing/20181221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

@[TOC](Python学习Day4-循环结构)
# 循环结构

## for-in循环
- 明确**知道循环执行的次数**
- 对一个容器进行迭代


```python
"""
用for循环实现1~100求和
Author: 郭大侠
"""

sum = 0
for x in range(101):
    sum += x
print(sum)
```

    5050
    

### `range` 用法
`range`可以产设一个不变的数值序列，而且这个序列通常用在循环中，例如：
- `range(101)`可以产生0到100的整数序列
- `range(1,100)`可以产生一个1到99的整数序列
- `range(1,100,2)`产生一个1到99的奇数序列，2为步长，即增量


```python
"""
用for循环实现1~100之间的偶数求和
Author: 郭大侠
"""

sum = 0
for x in range(2,101,2):
    sum += x
print(sum)
```

    2550
    

## while循环
- 不知道循环次数


```python
"""
猜数字游戏
计算机出一个1~100之间的随机数由人来猜
计算机根据人猜的数字分别给出提示大一点/小一点/猜对了
Author: 郭大侠
"""

import random

answer = random.randint(1, 100)
counter = 0
while True:
    counter += 1
    number = int(input('请输入: '))
    if number < answer:
        print('大一点')
    elif number > answer:
        print('小一点')
    else:
        print('恭喜你猜对了!')
        break
print('你总共猜了%d次' % counter)
if counter > 7:
    print('你的智商余额明显不足')
```

    请输入: 3
    大一点
    请输入: 2
    大一点
    请输入: 8
    大一点
    请输入: 100
    小一点
    请输入: 50
    大一点
    请输入: 60
    小一点
    请输入: 55
    大一点
    请输入: 57
    大一点
    请输入: 58
    恭喜你猜对了!
    你总共猜了9次
    你的智商余额明显不足
    
   ### `random`产生一个随机数
   `random`用法[参考](https://www.jb51.net/article/133820.htm)
   #### `random`重要函数
   - `random()` 返回0<=n<1之间的随机实数n；
   - `random.randint(1,100)`产生一个1<=n<100之间的随机整数数
   - `choice(seq)` 从序列seq中返回随机的元素；
   ```python
   import random
a = random.choice([1, 2, 3, 4])
print(a)
   ```
   - `getrandbits(n)` 以长整型形式返回n个随机位；
   - `shuffle(seq[, random])` 原地指定seq序列；
   - `sample(seq, n)` 从序列seq中选择n个随机且独立的元素；
#### `random`模块方法说明
- `random.random()`函数是这个模块中最常用的方法了，它会生成一个随机的浮点数，范围是在0.0~1.0之间。
- `random.uniform()`正好弥补了上面函数的不足，它可以设定浮点数的范围，一个是上限，一个是下限。
- `random.randint()`随机生一个整数int类型，可以指定这个整数的范围，同样有上限和下限值，python random.randint。
- `random.choice()`可以从任何序列，比如list列表中，选取一个随机的元素返回，可以用于字符串、列表、元组等。
- `random.shuffle()`如果你想将一个序列中的元素，随机打乱的话可以用这个函数方法。
- `random.sample()`可以从指定的序列中，随机的截取指定长度的片断，不作原地修改。
> **说明：**上面的代码中使用了`break`关键字来提前终止循环，需要注意的是`break`只能终止它所在的那个循环，这一点在使用嵌套的循环结构（下面会讲到）需要引起注意。除了`break`之外，还有另一个关键字是`continue`，它可以用来放弃本次循环后续的代码直接让循环进入下一轮。

