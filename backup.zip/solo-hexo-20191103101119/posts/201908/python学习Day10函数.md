title: python学习Day10-函数
date: '2019-08-02 23:23:52'
updated: '2019-08-02 23:23:52'
tags: [python]
permalink: /articles/2019/08/02/1564759432073.html
---
@[TOC](python学习Day10-函数)
## 函数


```python
a = 10
b = 20
a+b
```




    30



### 无参


```python
## 定义函数,无参
def print_value():
    print ('a=',a)
## 调用函数
print_value()
```

    a= 10
    

### 有参


```python
# 有参数
def add_ab(a,b):
    print(a+b)
add_ab(3,5)
```

    8
    

### 不定参数个数

#### 不定值个数（*）


```python
def add_number(a,*args):
    for i in args:
        a+=i
    return a
add_number(1,2,3,4)
```




    10




```python
add_number(1,2)
```




    3



#### 不定字典类型个数（**）


```python
def add_number2(a,**kwargs):
    for arg,value in kwargs.items():
        print(arg,value)
add_number2(1,x=2,y=3)
```

    x 2
    y 3
    

 `未完待续`

