title: lunix（ubuntu）开机自启动服务及docker自启动服务（tomcat）
date: '2019-09-07 11:09:30'
updated: '2019-09-07 11:22:01'
tags: [lunix, python, java]
permalink: /articles/2019/09/07/1567825770186.html
---
![](https://img.hacpai.com/bing/20190405.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 一、lunix下开机自动服务以java进程为例子
## 1、编写 '' jar' 包自启动脚本'' jarstart.sh'

```

#!/bin/bash  # 必须要的，执行方式
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64  # export JAVA_HOME=自己的JAVA_HOME
export JRE_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64/jre # export JAVA_HOME=自己的JAVA_HOME/jar
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib:$CLASSPATH #不变
export PATH=$JAVA_HOME/bin:$PATH # 不变

cd /home/guokai/taizhangxitong/   # 切换到jar包所在目录
nohup java -jar taizhangxitong2.5.3.jar >log2.5.3.txt 2>&1 &    # 后台执行jar包
```
## 2、将''jarstart.sh'添加至''/etc/rc.local'

```
vi /etc/rc.local
```

```
#!/bin/sh -e
#
# rc.local
#
# This script is executed at the end of each multiuser runlevel.
# Make sure that the script will "exit 0" on success or any other
# value on error.
#
# In order to enable or disable this script just change the execution
# bits.
#
# By default this script does nothing.
/etc/jarstart.sh   # 添加执行脚本
exit 0

```
## 3、重启''reboot'或刷新''resoure /etc/rc.local'
# 二、Linux下Python脚本自启动与定时任务详解
## 1、让Python随Linux开机自动运行

准备好要自启的脚本port.py

用root权限编辑以下文件

```
vi /ect/rc.local
```
在exit 0上面编辑启动脚本的命令

```
# 这里的python3加入了环境变量，在任何位置都可以执行，保险起见可以加python3路径
nohup python3 /home/guokai/taizhangxitong/pythonfile/port.py > /home/guokai/taizhangxitong/pythonfile/port.log 2>&1 &
```

> Linux下查看Python安装路径
> 交互模式下

```
>>> import sys
>>> print(sys.path)
['', '/usr/lib/python35.zip', '/usr/lib/python3.5', '/usr/lib/python3.5/plat-x86_64-linux-gnu', '/usr/lib/python3.5/lib-dynload', '/usr/local/lib/python3.5/dist-packages', '/usr/lib/python3/dist-packages']
>>> 

```
## 2、让Python脚本定时启动
准备好定时启动的脚本port.py

用root权限编辑以下文件

```
sudo vim /etc/crontab
```

在文件末尾添加以下命令

```
2 * * * * root nohup python3 /home/guokai/taizhangxitong/pythonfile/port.py > /home/guokai/taizhangxitong/pythonfile/port.log 2>&1 &
```

以上代码的意思是每隔两分钟执行一次脚本并打印日志。

>crontab编写解释

基本格式

```
* * * * * user command
```

分 时 日 月 周 用户 命令
## 3、举例说明
1、每分钟执行一次 

```
* * * * * user command
```

2、每隔2小时执行一次 

```
* */2 * * * user command (/表示频率)
```

3、每天8:30分执行一次

```
30 8 * * * user command
```

4、每小时的30和50分各执行一次 

```
30,50 * * * * user command（,表示并列）
```

4、每个月的3号到6号的8:30执行一次

```
30 8 3-6 * * user command （-表示范围）
```

5、每个星期一的8:30执行一次

```
30 8 * * 1 user command （周的范围为0-7,0和7代表周日）
```
# 三、docker自启动及docker内置服务自启动

## 1、docker容器自启动
- 未运行容器


```
docker run -dit --restart unless-stopped 镜像
```

- 运行中容器

```
docker update --restart=always 容器ID
```

## 2、利用Dockerfile创建一个tomcat镜像，并运行一个简单war包
### 新建Dockerfile文件

```
vi Dockerfile
```

```
FROM tomcat # tomcat是已经下好的镜像文件，以此镜象重构tomcat镜像
 
MAINTAINER liu "715182260@qq.com"
 
 
#设置环境变量，重要由于基础镜像tomcat内置了Java环境只要echo $JAVA_HOME就可以打印出来（先用基础景象构建容器，进入容器中）
ENV JAVA_HOME=/usr/local/openjdk-8
ENV JRE_HOME=$JAVA_HOME/jre
ENV CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib:$CLASSPATH
ENV PATH=/sbin:$JAVA_HOME/bin:$PATH
 
#设置启动命令
ENTRYPOINT ["/usr/local/tomcat/bin/catalina.sh","run"]
```
### 重构镜像
在Dockerfile所在目录下执行
```
docker build -t guokai01/tomcat .
```

```
root@ubuntu:/home/guokai# docker build -t guokai01/tomcat .
Sending build context to Docker daemon  1.911GB
Step 1/7 : FROM tomcat
 ---> 96c4e536d0eb
Step 2/7 : MAINTAINER liu "715182260@qq.com"
 ---> Using cache
 ---> 8e5154795d8c
Step 3/7 : ENV JAVA_HOME=/usr/local/openjdk-8
 ---> Using cache
 ---> c66edd180877
Step 4/7 : ENV JRE_HOME=$JAVA_HOME/jre
 ---> Using cache
 ---> ec86af3e4375
Step 5/7 : ENV CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib:$CLASSPATH
 ---> Using cache
 ---> 4eb2b2da04e9
Step 6/7 : ENV PATH=/sbin:$JAVA_HOME/bin:$PATH
 ---> Using cache
 ---> 3b30642b8640
Step 7/7 : ENTRYPOINT ["/usr/local/tomcat/bin/catalina.sh","run"]
 ---> Using cache
 ---> a3f19a7c98a8
Successfully built a3f19a7c98a8
Successfully tagged guokai01/tomcat:latest
```

```
root@ubuntu:/home/guokai# docker images
REPOSITORY                        TAG                 IMAGE ID            CREATED             SIZE
guokai01/tomcat                   latest              a3f19a7c98a8        2 days ago          506MB
```
### 通过创建好的镜像，启动一个容器

```
docker run -d -p 8383:8080 --name hmk_tomcat guokai01/tomcat:latest
```
> tomcat 服务已经自启动

![微信图片20190907110025.png](https://img.hacpai.com/file/2019/09/微信图片20190907110025-3288077b.png)

### 进入容器

```
root@ubuntu:/home/guokai# docker ps
CONTAINER ID        IMAGE                             COMMAND                  CREATED             STATUS              PORTS                                                                                        NAMES
e473a678c1eb        guokai01/tomcat:latest              "/usr/local/tomcat/b…"   2 days ago          Up 16 hours         0.0.0.0:8383->8080/tcp                                                                       hmk_tomcat
```


```
docker exec -it e473a678c1eb /bin/bash
```
> 挂载目录（新建容器时）
-v 主机目录:容器目录