title: Python生成可执行文件exe
date: '2019-09-18 12:05:18'
updated: '2019-09-18 12:05:18'
tags: [python]
permalink: /articles/2019/09/18/1568779518521.html
---
# 1 ，下载`pyinstaller`
```
pip install pyinstaller
```
# 2， 执行`pip list`可以查看当前的安装的工具
# 3 ，安装的pyinstaller 文件目录
`pyinstaller.exe  `( Scripts目录中 )
![null](https://img-blog.csdn.net/20180614151627954?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1Zpc3J1bA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
` pyinstaller` 源文件（site-packages目录中）
![null](https://img-blog.csdn.net/20180614151810490?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1Zpc3J1bA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

# 4，打包！！


- `pyinstaller xxx.py`
   生成多个文件，执行较快！！
打包好的文件在dist里面，生成了好多文件。
- **pyinstaller -F main.py**
生成一个文件，程序启动较慢！！
# 打包问题
Pyinstaller 打包常见问题总汇（欢迎补充）：

## UnicodeDecodeError: ‘utf-8’ codec can’t decode byte 0xce in position XXX: invalid continuation b
a.删除中文注释
b. 在运行pyinstaller 前先在cmd里输入
chcp 65001

## 如果程序比较复杂先生成.spec文件方便对打包过程进行修改
``
在spec里开头加一句：
```
import sys   
sys.setrecursionlimit(100000)
```

##  一些第三方库没有加载打包
可在 spec 中analysis里的 hiddenimports 加入你要的库：
```
a = Analysis([‘data_db_importer_pandas.py’],
pathex=[‘D:\work\。。。。。。’],
binaries=[],
datas=[],
hiddenimports=[‘cython’, ‘sklearn’, ‘sklearn.ensemble’,‘sklearn.neighbors.typedefs’,‘sklearn.neighbors.quad_tree’,‘sklearn.tree._utils’,‘scipy._lib.messagestream’],
hookspath=[],
runtime_hooks=[],
excludes=[],
win_no_prefer_redirects=False,
win_private_assemblies=False,
cipher=block_cipher)

```
