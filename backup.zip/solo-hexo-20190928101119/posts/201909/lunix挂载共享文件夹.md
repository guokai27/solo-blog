title: lunix挂载共享文件夹
date: '2019-09-19 14:20:39'
updated: '2019-09-19 14:20:39'
tags: [lunix]
permalink: /articles/2019/09/19/1568874039122.html
---
# lunix挂载共享文件夹
## 一、背景
- 通常会有这样的场景，开发人员在Windows编写代码，然后放在linux环境编译


- lunix运行代码，将文件存入windows


我们通过mount命令就可以实现将代码直接挂到linux环境上去，使Windows上的共享文件夹就像linux环境中的一个文件夹。
## 二、在Windows上共享文件夹
- 1. 选择要共享的文件夹 --> 右键-->属性->共享选项->共享： 选择Everyone，这样任何用户都可以访问。

- 2. 共享完成后，可以通过其他可访问你主机的机器测试，地址格式：\\xxx.xxx.xxx.xxx\share,  \\你的ip\\你共享的文件夹名

>注意：默认情况下Windows共享文件夹只有为计算机设置了密码才能共享。解决这个问题可以有两种方式：
1.老老实实的设置密码就好了
2.在网络和共享中心，关闭共享文件夹密码保护即可

## 三、在linux上挂载共享文件夹

- 1. 首先创建你要映射的目录，比如我创建的是目录是： /root/share/
- 2. 用mount命令挂载：　　　　
```
mount -t cifs -o username=share,password=share,rw,file_mode=0777,dir_mode=0777,uid=0,gid=0,vers=2.1  //192.168.1.120/share /root/share
```
> 其中：
1） //1962.168.1.120/share 为windows的主机ip/共享文件名
2）/root/share 为linux上映射的文件夹
3）username=share,password=share表示windows上的用户名和密码，
4）rw, file_mode, dir_mode 为linux上的文件夹和文件的权限
5）setuid=0, setgid=0 linux用户id和组id，这个一定要设置，如果不设置，就算第4步增加了权限，linux上还是不能修改文件的。 uid=0和gid=0，表示root用户  
6)vers=2.1这个不设置有可能会报错

## 四、查看挂载

```
使用 # mount 也可进行查看
```
## 五、卸载挂载

```
使用umount命令：   umount  root/share
```

　　若文件被占用，omount命令会失败提示如下：  `target is busy. (In some cases useful info about processes that use the device is found by lsof(8) or fuser(1))`

　　1） 先切换到别的目录试一下，如果不可以那可能是别的进程占用了文件

　　2）使用# fuser命令查看： fuser /root/share 查看被哪个进程占用了，然后kill掉进程在umount就行了

## 六、开机自动挂载
参考[lunix（ubuntu）开机自启动服务及docker自启动服务（tomcat）](http://www.guokaiblog.cn/articles/2019/09/07/1567825770186.html)

