title: python学习Day7-字典
date: '2019-08-02 23:22:03'
updated: '2019-08-02 23:22:03'
tags: [python]
permalink: /articles/2019/08/02/1564759323845.html
---
![](https://img.hacpai.com/bing/20181117.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


@[TOC](python学习Day7-字典)
## 字典结构（key:value）


```python
tang = {}
```


```python
type(tang)
```




    dict



### 字典初始化（不建议）


```python
tang = dict()
type(tang)
```




    dict




```python
tang = dict([('tang',12),('yu',34)])
tang
```




    {'tang': 12, 'yu': 34}



## 字典结构操作

### 赋值（键值唯一）


```python
tang['first'] = 123
tang
```




    {'first': 123}




```python
tang['second'] = 456
tang
```




    {'first': 123, 'second': 456}




```python
tang['first'] = 123
tang
```




    {'first': 123, 'second': 456}



### 取值


```python
tang['second']
```




    456



### 更新键值


```python
tang['second'] = 789
tang
```




    {'first': 123, 'second': 789}



### 3.6之前字典无序
- 在3.6版本之后字典有序


```python
tang = {'tang':123,'yu':456,'di':789}
tang
```




    {'tang': 123, 'yu': 456, 'di': 789}



- 索引要用键


```python
tang[0]
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    <ipython-input-14-63a9ea6f1cbb> in <module>
    ----> 1 tang[0]
    

    KeyError: 0



```python
tang['tang']
```




    123



### 字典的数值类型


```python
tang_value = [1,2,3]
tang = {}
tang['first'] = tang_value
tang['second'] = 3
tang['third'] = 'kai'
tang
```




    {'first': [1, 2, 3], 'second': 3, 'third': 'kai'}



### 字典嵌套


```python
tang = {}
d1 = {'first':13,'second':45}
d2 = {'first1':78,'second2':90}
tang['test1'] = d1
tang['test2'] = d2
tang
```




    {'test1': {'first': 13, 'second': 45}, 'test2': {'first1': 78, 'second2': 90}}



### 字典索引
- key值下标或get方法


```python
tang = {'first':123,'second':456}
```


```python
tang['first']
```




    123




```python
tang.get('first')
```




    123




```python
tang['kai']
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    <ipython-input-25-80602900b100> in <module>
    ----> 1 tang['kai']
    

    KeyError: 'kai'



```python
tang.get('kai','没有')
```




    '没有'



### 弹出（pop）


```python
tang.pop('first')
```




    123




```python
tang
```




    {'second': 456}



### 删除


```python
del tang['second']
```


```python
tang
```




    {}



### 字典更新


```python
tang = {'first':123,'second':456}
tang1 = {'first':789,'third':'新增'}
```


```python
tang.update(tang1)
tang
```




    {'first': 789, 'second': 456, 'third': '新增'}



### 判断key是否在字典中（in）


```python
'first' in tang
```




    True




```python
'forth' in tang
```




    False



### 打印所有的键


```python
tang.keys()
```




    dict_keys(['first', 'second', 'third'])



### 打印所有的键值


```python
tang.values()
```




    dict_values([789, 456, '新增'])



### 打印键和键值组合


```python
tang.items()
```




    dict_items([('first', 789), ('second', 456), ('third', '新增')])



`未完待续`

