title: python学习Day14-类
date: '2019-08-02 23:26:07'
updated: '2019-08-02 23:26:07'
tags: [python]
permalink: /articles/2019/08/02/1564759567216.html
---
@[TOC](python学习Day14-类)
## 类：面向对象


```python
class people:
    '帮助信息：XXXXX'
    number = 100
    #构造函数，初始化__init__；self必须指定的额外参数
    def __init__(self,name,age):
        self.name = name
        self.age = age
    def display(self):
        print('number = :',people.number)
    def display_name(self):
        print(self.name)
        
```

## 类的帮助信息/说明(__doc__)


```python
people.__doc__
```




    '帮助信息：XXXXX'



## 类的实例化

### 实例


```python
p1 = people('tang',30)
```


```python
p2 = people('php',40)
```

### 调用属性


```python
p1.name
```




    'tang'



### 调用方法


```python
p1.display()
```

    number = : 100
    


```python
p2.display()
```

    number = : 100
    

### 修改属性


```python
p2.name
```




    'php'




```python
p2.name = 'java'
```


```python
p2.name
```




    'java'




```python
del p2.name
```


```python
p2.name
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    <ipython-input-25-1fe4036a7206> in <module>
    ----> 1 p2.name
    

    AttributeError: 'people' object has no attribute 'name'


### 判断属性是否存在（hasattr）


```python
hasattr(p1,'name')
```




    True




```python
hasattr(p2,'name')
```




    False




```python
hasattr(p1,'sex')
```




    False



### 属性获取（getattr）


```python
getattr(p1,'name')
```




    'tang'



### 属性设置（setattr）


```python
setattr(p1,'name','kai')
```


```python
getattr(p1,'name')
```




    'kai'



## 类的内置属性


```python
#类的说明
print(people.__doc__)
#类的名字
print(people.__name__)
#类的模块
print(people.__module__)
#类的父类构成的元素
print(people.__bases__)
#类的整体组成
print(people.__dict__)
```

    帮助信息：XXXXX
    people
    __main__
    (<class 'object'>,)
    {'__module__': '__main__', '__doc__': '帮助信息：XXXXX', 'number': 100, '__init__': <function people.__init__ at 0x00000199D0BE0730>, 'display': <function people.display at 0x00000199D0BE08C8>, 'display_name': <function people.display_name at 0x00000199D0BE0950>, '__dict__': <attribute '__dict__' of 'people' objects>, '__weakref__': <attribute '__weakref__' of 'people' objects>}
    

## 类的继承


```python
class Parent:#定义父类
    number = 100
    def __init__(self):
        print('调用父类构造函数')
    def parentM(self):
        print('调用父用方法')
    def setAttr(self,attr):
        Parent.parentAttr = attr
    def getAttr(self):
        print('父类属性：',Parent.parentAttr)
    def newM(self):
        print('父类要被重写的方法')
    
class Child(Parent):#定义子类
    def __init__(self):
        print('调用子类构造函数')
    def childM(self):
        print('调用子类方法')
    def newM(self):
        print('子类改掉的方法')
    
```

### 子类的实例化


```python
c = Child()
c.childM()
```

    调用子类构造函数
    调用子类方法
    

### 调用父类的方法


```python
c.parentM()
c.setAttr(100)
c.getAttr()
```

    调用父用方法
    父类属性： 100
    

> 注意：子类不会调用父类的构造函数

### 方法重写


```python
c.newM()
```

    子类改掉的方法
    

==未完待续==

