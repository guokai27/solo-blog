title: python学习Day9-赋值结构
date: '2019-08-02 23:23:22'
updated: '2019-08-02 23:23:22'
tags: [python]
permalink: /articles/2019/08/02/1564759402457.html
---
@[TOC](python学习Day9-赋值结构)
## 内存指向（id）

### 传值，只想同一个值的内存空间


```python
tang = 100
kai = tang
id(tang)
```




    140706107531168




```python
id(kai)
```




    140706107531168




```python
kai  is tang
```




    True




```python
kai = 102
```


```python
id(kai)
```




    140706107531232




```python
kai is tang
```




    False



### 赋值，指向新的内存空间


```python
tang = 1000
kai = 1000
id(tang)
```




    1819631143248




```python
id(kai)
```




    1819631143216




```python
kai is tang
```




    False



### 赋值重用，节省内存，将简单或比较小的值重用


```python
tang = 1
kai = 1
id(tang)
```




    140706107528000




```python
id(kai)
```




    140706107528000




```python
kai is tang
```




    True



`未完待续`

