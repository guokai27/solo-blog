title: Python学习Day3-分支结构
date: '2019-08-02 23:18:52'
updated: '2019-08-02 23:18:52'
tags: [python]
permalink: /articles/2019/08/02/1564759132271.html
---
![](https://img.hacpai.com/bing/20190621.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


@[TOC](分支结构)
# 分支结构-if

## 关键字`if`、`elif` 、`else`


```python
"""
用户身份验证
Author: 郭大侠
"""
import getpass
username = input('请输入用户名: ')
# password = input('请输入口令: ')
# 如果希望输入口令时 终端中没有回显 可以使用getpass模块的getpass函数
password = getpass.getpass('请输入口令: ')
if username == 'admin' and password == '123456':
    print('身份验证成功!')
else:
    print('身份验证失败!')
```

    请输入用户名: admin
    请输入口令: ········
    身份验证成功!
    

## 分支嵌套（不提倡）


```python
"""
分段函数求值

        3x - 5  (x > 1)
f(x) =  x + 2   (-1 <= x <= 1)
        5x + 3  (x < -1)

Author: 郭大侠
"""

x = float(input('x = '))
if x > 1:
    y = 3 * x - 5
elif x >= -1:
    y = x + 2
else:
    y = 5 * x + 3
print('f(%.2f) = %.2f' % (x, y))
```

    x = 2
    f(2.00) = 1.00
    


```python
"""
分段函数求值
		3x - 5	(x > 1)
f(x) =	x + 2	(-1 <= x <= 1)
		5x + 3	(x < -1)

Author: 郭大侠
"""

x = float(input('x = '))
if x > 1:
    y = 3 * x - 5
else:
    if x >= -1:
        y = x + 2
    else:
        y = 5 * x + 3
print('f(%.2f) = %.2f' % (x, y))
```

    x = 2
    f(2.00) = 1.00
    

> **说明：**大家可以自己感受一下这两种写法到底是哪一种更好。在之前我们提到的Python之禅中有这么一句话“Flat is better than nested.”，之所以提出这个观点是因为嵌套结构的嵌套层次多了之后会严重的影响代码的可读性，如果可以使用扁平化的结构就不要去用嵌套，因此之前的写法是更好的做法。

