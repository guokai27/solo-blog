title: Python学习Day6-列表
date: '2019-08-02 23:21:22'
updated: '2019-08-02 23:21:22'
tags: [python]
permalink: /articles/2019/08/02/1564759281995.html
---
![](https://img.hacpai.com/bing/20180630.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

@[toc](Python学习Day6-列表)
# 列表

## 列表格式


```python
tang = []

```


```python
type(tang)
```




    list



## 列表中的元素类型不定


```python
tang = ['kai',1,3.2]
```


```python
tang
```




    ['kai', 1, 3.2]



## 列表声明（不建议）


```python
tang = list([1,22,3])
```


```python
tang
```




    [1, 22, 3]



## list操作

### list长度


```python
len(tang)
```




    3



### list加法


```python
a = [123,456]
b =['tang','kai']
a+b
```




    [123, 456, 'tang', 'kai']




```python
type(a+b)
```




    list



### list乘法(相当于复制)


```python
a*2
```




    [123, 456, 123, 456]



## list索引

### 下标索引


```python
a[0]
```




    123



### 下标起始索引


```python
a[0:]
```




    [123, 456]




```python
b = [1,2,3,4,5,6]
b[1:]
```




    [2, 3, 4, 5, 6]



## 元素替换


```python
b[0]=9
b
```




    [9, 2, 3, 4, 5, 6]



## 列表切片(包左不包右)


```python
b[2:3]
```




    [3]




```python
b[2:4]
```




    [3, 4]



## 列表元素删除

### 删除单一元素


```python
del b[0]
b
```




    [2, 3, 4, 5, 6]



### 批量删除


```python
del  b[3:]
```


```python
b
```




    [1, 2, 3]



## 判断列表元素是否存在(in)


```python
a = [1,2,3,4,5,6,7,8,9]
8 in a
```




    True




```python
10 in a
```




    False



### 字符串同理


```python
tang = 'python java vue'
'vue' in tang
```




    True




```python
'php' in tang
```




    False



## list嵌套(多用于二维数组)


```python
a = [1,[2,3],4]
a
```




    [1, [2, 3], 4]




```python
a[1]
```




    [2, 3]




```python
a[1][0]
```




    2



## list计数


```python
tang = ['app','bana','app','app','bana','bana','bana','bana','bana','bana','bana']
tang.count('app')
```




    3



## list查找索引(返回第一个索引)


```python
tang.index('app')
```




    0



## 列表添加

### 顺序添加(append)默认从后面添加


```python
tang = []
```


```python
tang.append('app')
tang
```




    ['app']




```python
tang.append([1,2])
tang
```




    ['app', [1, 2]]



### 插入（insert）


```python
tang.insert(0,'python')
```


```python
tang
```




    ['python', 'app', [1, 2]]




```python
tang.insert(2,'python')
tang
```




    ['python', 'app', 'python', [1, 2]]



## 删除

### 顺序删除(remove)默认从第一个删除


```python
tang.remove('python')
tang
```




    ['app', 'python', [1, 2]]



### 指定删除，弹出（pop）


```python
tang.pop(1)
```




    'python'




```python
tang
```




    ['app', [1, 2]]



## 排序

### 改变原始数据（sort）


```python
tang = [2,4,6,3,7,1,9,8]
```


```python
tang.sort()
tang
```




    [1, 2, 3, 4, 6, 7, 8, 9]



### 不改变原始数据（sorted）


```python
tang = [2,4,6,3,7,1,9,8]
tang1 = sorted(tang)
```


```python
tang
```




    [2, 4, 6, 3, 7, 1, 9, 8]




```python
tang1
```




    [1, 2, 3, 4, 6, 7, 8, 9]



### 倒序（reverse）


```python
tang = ['shuai','kai','guo']
tang.reverse()
```


```python
tang
```




    ['guo', 'kai', 'shuai']



`未完待续`

