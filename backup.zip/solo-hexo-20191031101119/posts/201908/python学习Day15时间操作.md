title: python学习Day15-时间操作
date: '2019-08-02 23:26:37'
updated: '2019-08-02 23:26:37'
tags: [python]
permalink: /articles/2019/08/02/1564759597693.html
---
@[TOC](python学习Day15-时间操作)
## 导入时间模块


```python
import time
```

### 时间戳（time()）


```python
print(time.time())
```

    1561698370.1692884
    

### 本地时间（localtime(time.time())）,将时间戳换算


```python
print(time.localtime(time.time()))
```

    time.struct_time(tm_year=2019, tm_mon=6, tm_mday=28, tm_hour=13, tm_min=8, tm_sec=9, tm_wday=4, tm_yday=179, tm_isdst=0)
    

> 注意：星期为tm_wday加1

### 时间格式化(asctime())


```python
print(time.asctime(time.localtime(time.time())))
```

    Fri Jun 28 13:12:23 2019
    

### 自定义时间格式（strftime()）


```python
print(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
```

    2019-06-28 13:15:38
    

## 日历


```python
import calendar
print(calendar.month(2019,6))
```

         June 2019
    Mo Tu We Th Fr Sa Su
                    1  2
     3  4  5  6  7  8  9
    10 11 12 13 14 15 16
    17 18 19 20 21 22 23
    24 25 26 27 28 29 30
    
    

## 函数帮助命令（help()）


```python
print(help(calendar.month))
```

    Help on method formatmonth in module calendar:
    
    formatmonth(theyear, themonth, w=0, l=0) method of calendar.TextCalendar instance
        Return a month's calendar string (multi-line).
    
    None
    

==未完待续==

