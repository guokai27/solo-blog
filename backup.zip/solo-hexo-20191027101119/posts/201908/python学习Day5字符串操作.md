title: python学习Day5-字符串操作
date: '2019-08-02 23:20:39'
updated: '2019-08-02 23:20:39'
tags: [python]
permalink: /articles/2019/08/02/1564759239450.html
---
![](https://img.hacpai.com/bing/20181221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

@[TOC](python学习Day5-字符串操作)
# 字符串算法

## 字符串加法


```python
tang ='hello'+'python'
tang
```




    'hellopython'



## 字符串乘法


```python
tang*3
```




    'hellopythonhellopythonhellopython'



## 字符串长度


```python
len(tang)
```




    11



# 字符串操作

## 字符串切片


```python
tang = '1 2 3 4 5'
tang.split()
```




    ['1', '2', '3', '4', '5']




```python
tang = '1,2,3,4,5'
tang=tang.split(',')
tang
```




    ['1', '2', '3', '4', '5']



## 字符串合并


```python
tang_str = ''
tang_str.join(tang)
```




    '12345'



## 字符串替换


```python
tang = 'hello python'
tang.replace('python','java')
```




    'hello java'




```python
tang
```




    'hello python'




```python
tang1 = tang.replace('python','java')
tang1
```




    'hello java'



`- 替换的字符串，并不改变原有变量 `

## 大小写转化


```python
tang1.upper()
```




    'HELLO JAVA'




```python
tang1 = 'HEllo'
tang1.lower()
```




    'hello'



## 去掉多余空格

### 去掉左右两边空格


```python
tang = '        hello python  '
tang.strip()
```




    'hello python'



### 去掉左边空格


```python
tang.lstrip()
```




    'hello python  '



### 去掉右方空格


```python
tang.rstrip()
```




    '        hello python'



## 规则传递字符串

### 指定数量


```python
'{} {} {}'.format('tang','yu','di')
```




    'tang yu di'



### 指定顺序


```python
'{2} {1} {0}'.format('tang','yu','di')
```




    'di yu tang'



### 指定参数


```python
'{tang} {yu} {di}'.format(tang=10,yu=5,di=1)
```




    '10 5 1'



### 旧式%规则（不推荐）


```python
tang = 'hello world'
a = 123.0
b = 456
result = '%s %f %d' % (tang,a,b)
result
```




    'hello world 123.000000 456'



`未完待续`
