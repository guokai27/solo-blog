title: python学习Day11-模块与包
date: '2019-08-02 23:24:25'
updated: '2019-08-02 23:24:25'
tags: [python]
permalink: /articles/2019/08/02/1564759465188.html
---
@[TOC](python学习Day11-模块与包)
## notebook创建脚本文件（%%writefile 文件名）


```python
%%writefile tang.py
tang_v = 10
def tang_add(tang_list):
    tang_sum = 0
    for i in range(len(tang_list)):
        tang_sum += tang_list[i]
    return tang_sum
tang_list = [1,2,3,4,5]
print(tang_add(tang_list))
```

    Writing tang.py
    

## 运行脚本文件（%run 文件名）


```python
%run tang.py
```

    15
    

## 导入脚本文件 (import 导入模块只运行一次)


```python
import tang
```

    15
    


```python
import tang
```

### 导入文件的名字和路径


```python
tang
```




    <module 'tang' from 'F:\\pythonStudy\\tang.py'>



### 包取值


```python
print (tang.tang_v)
```

    10
    

### 包取函数


```python
tang_list = [10,11,12]
tang.tang_add(tang_list)
```




    33



### 包取别名


```python
import tang as tg
```


```python
tg.tang_v
```




    10



### 部分调用


```python
from tang import tang_v,tang_add
```


```python
tang_v
```




    10




```python
tang_add(tang_list)
```




    33



### 全部导入


```python
from tang import *
```


```python
tang_add(tang_list)
```




    15



## 删除脚本文件


```python
import os
os.remove('tang.py')
```

`未完待续`

