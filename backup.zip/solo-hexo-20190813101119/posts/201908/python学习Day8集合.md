title: python学习Day8-集合
date: '2019-08-02 23:22:46'
updated: '2019-08-02 23:22:46'
tags: [python]
permalink: /articles/2019/08/02/1564759366405.html
---
![](https://img.hacpai.com/bing/20180501.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

@[TOC](python学习Day8-集合)
## 集合（set）一般帮列表去重

### 去重


```python
tang = [123,123,456,789]
tang = set(tang)
```


```python
tang
```




    {123, 456, 789}



### 结构


```python
tang = set()
type(tang)
```




    set



## 集合的操作

### 并(union或 | )


```python
a = {1,2,3,4,5,6}
b = {3,4,5,6,7,8}
a.union(b)
```




    {1, 2, 3, 4, 5, 6, 7, 8}




```python
b.union(a)
```




    {1, 2, 3, 4, 5, 6, 7, 8}




```python
a|b
```




    {1, 2, 3, 4, 5, 6, 7, 8}



### 交（intersection或 & ）


```python
a.intersection(b)
```




    {3, 4, 5, 6}




```python
b.intersection(a)
```




    {3, 4, 5, 6}




```python
a & b
```




    {3, 4, 5, 6}



### 差（difference或 - ）


```python
a.difference(b)
```




    {1, 2}




```python
b.difference(a)
```




    {7, 8}




```python
a - b
```




    {1, 2}




```python
b - a
```




    {7, 8}



### 判断包含关系（issubset或<=、>）


```python
a = {1,2,3,4,5,6}
b = {2,3,4}
b.issubset(a)
```




    True




```python
b <= a
```




    True




```python
a.issubset(b)
```




    False




```python
b > a
```




    False



### 添加元素（add）


```python
a = {1,2,3}
a.add(4)
a
```




    {1, 2, 3, 4}



### 更新(update)


```python
a.update([2,3,4,5])
a
```




    {1, 2, 3, 4, 5}



### 删除元素（remove）


```python
a.remove(2)
a
```




    {1, 3, 4, 5}



### 弹出元素（pop）与列表和字典不同
- 不能用下标弹出，只能从第一个依次弹出


```python
a.pop()
```




    1




```python
a.pop()
```




    3



`未完待续`

